/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  SA076menu.h                                                          */
/*  PRINCIPAL AUTHOR      :  Zhangfan                                                             */
/*  SUBSYSTEM NAME        :  SA076menu                                                            */
/*  MODULE NAME           :  SA076menu                                                            */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/25                                                           */
/*  DESCRIPTION           :  interface of menu                                                    */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhangfan, 2014/09/25
 *
 */

#include "linktable.h"

typedef struct DataNode
{  
    tLinkTableNode * pNext;
    int     num;	
    char*   cmd;
    char*   desc;
    char*   value;
    int     (*handler)();  
} tDataNode;

/* translate tDataNode[] into LinkTable */
tLinkTable *initMenu(tDataNode *menu);

/* get cmd list */
int showAllCmd(tLinkTable * head);

/* get desc by cmd num */
tDataNode* getByNum(tLinkTable * head, int num);

/* get desc by cmd */
tDataNode* getByCmd(tLinkTable * head, char * cmd);

/* get Length of the tDataNode variable */
int getNodeLength(tLinkTable * head);




