﻿学号：SA14225076

姓名：张帆 


编译：gcc testcase.c linktable.c SA076menu.c testSA076menu.c -o test


运行：./test
 
